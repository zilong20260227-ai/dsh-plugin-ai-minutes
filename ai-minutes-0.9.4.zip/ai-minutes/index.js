import { spawn, execFile } from 'node:child_process'
import { createServer } from 'node:http'
import { chmodSync, copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { tmpdir } from 'node:os'

export const name = 'ai-minutes'

// Host 侧职责：维护到听记服务的 SSH 本地转发，面板据此直连 127.0.0.1:<port>
// 随包附带一把「只能端口转发」的共享密钥（服务端 authorized_keys 里带 restrict,port-forwarding），
// 装好即可用；如需连自己的机器，用 config.server / config.identity 覆盖。
const BACKOFF_MS = 3000
const HERE = dirname(fileURLToPath(import.meta.url))

function prepareIdentity(src) {
  // npm 包里的文件权限通常是 644，ssh 会拒绝；复制到临时目录并设成 600
  if (!existsSync(src)) return null
  try {
    const dir = join(tmpdir(), 'dsh-ai-minutes')
    mkdirSync(dir, { recursive: true })
    const dst = join(dir, 'id_ed25519')
    copyFileSync(src, dst)
    chmodSync(dst, 0o600)
    return dst
  } catch {
    return src
  }
}

// 用钉钉账号当身份：dws 已登录的那台机，直接读它的 corpId + userId，
// 同一个人换机器 / 重装插件仍然是同一个 owner，数据跟着人走。
function dingtalkIdentity() {
  return new Promise((resolve) => {
    execFile('dws', ['auth', 'status'], { timeout: 8000 }, (err, stdout) => {
      if (err) return resolve(null)
      try {
        const d = JSON.parse(stdout)
        if (!d || !d.authenticated || !d.user_id) return resolve(null)
        const corp = String(d.corp_id || '').slice(0, 6)
        resolve({
          owner: `dt_${corp}_${d.user_id}`,
          name: d.user_name || '',
          corp: d.corp_name || '',
        })
      } catch {
        resolve(null)
      }
    })
  })
}

// 把身份通过本机回环端口交给面板（浏览器读不了文件，也不该持有 dws 凭证）
function serveIdentity(getId, port, apiPort) {
  const srv = createServer((req, res) => {
    const id = getId()
    res.writeHead(200, {
      'content-type': 'application/json',
      'access-control-allow-origin': '*',
    })
    // apiPort 一并下发：面板据此决定连哪个本地端口，端口被占时改配置即可，不用重发前端
    res.end(JSON.stringify({ ...(id || {}), apiPort }))
  })
  srv.on('error', () => {})
  srv.listen(port, '127.0.0.1')
  return srv
}

// 设备令牌：第一次启动用邀请码换取，之后存在本机，重装也复用同一台设备身份
function deviceFile() {
  const dir = join(tmpdir(), 'dsh-ai-minutes')
  mkdirSync(dir, { recursive: true })
  return join(dir, 'device.json')
}

function readDevice() {
  try {
    return JSON.parse(readFileSync(deviceFile(), 'utf8'))
  } catch {
    return null
  }
}

async function registerDevice(apiPort, invite, name) {
  const r = await fetch(`http://127.0.0.1:${apiPort}/v1/devices/register`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ code: invite, name }),
    signal: AbortSignal.timeout(8000),
  })
  if (!r.ok) throw new Error(`注册失败 HTTP ${r.status}: ${(await r.text()).slice(0, 80)}`)
  const d = await r.json()
  const payload = { token: d.token, owner: d.owner, name: d.name || '' }
  writeFileSync(deviceFile(), JSON.stringify(payload), { mode: 0o600 })
  return payload
}

export function apply(ctx, config = {}) {
  const server = config.server || 'aim@49.232.162.240'
  const identity = prepareIdentity(
    config.identity || join(HERE, 'key', 'id_ed25519'),
  )
  const port = config.port || 8077
  const remotePort = config.remotePort || 8077
  const identityPort = config.identityPort || 8099
  const autoTunnel = config.autoTunnel !== false

  if (!autoTunnel) return
  if (!identity) {
    console.warn('[ai-minutes] 未找到 SSH 私钥，跳过自动隧道；请配置 config.identity')
    return
  }

  let child = null
  let timer = null
  let disposed = false

  const start = () => {
    if (disposed) return
    child = spawn('ssh', [
      '-N',
      '-o', 'BatchMode=yes',
      '-o', 'ExitOnForwardFailure=yes',
      '-o', 'ServerAliveInterval=20',
      '-o', 'ServerAliveCountMax=3',
      '-o', 'StrictHostKeyChecking=accept-new',
      '-o', 'ConnectTimeout=10',
      '-o', `UserKnownHostsFile=${join(tmpdir(), 'dsh_ai_minutes_known_hosts')}`,
      '-i', identity,
      '-L', `${port}:127.0.0.1:${remotePort}`,
      server,
    ], { stdio: 'ignore' })

    child.on('error', () => { child = null })
    child.on('exit', () => {
      child = null
      if (!disposed) timer = setTimeout(start, BACKOFF_MS)
    })
  }

  let dtIdentity = null
  let device = readDevice()

  const ensureDevice = async () => {
    let invite = config.invite || process.env.AIM_INVITE
    if (!invite) {
      // 安装脚本会把邀请码写到包目录下的 .invite，省掉手填配置
      try {
        invite = readFileSync(join(HERE, '.invite'), 'utf8').trim()
      } catch { /* 没有就跳过 */ }
    }
    if (device || !invite) return
    for (let i = 0; i < 20 && !device; i += 1) {
      try {
        // 等隧道通（本机回环端口起来）再注册
        await fetch(`http://127.0.0.1:${port}/healthz`, { signal: AbortSignal.timeout(2000) })
        const who = await dingtalkIdentity()
        device = await registerDevice(port, invite, (who && who.name) || '')
        console.log('[ai-minutes] 设备已注册')
      } catch {
        await new Promise((r) => setTimeout(r, 3000))
      }
    }
    if (!device) console.warn('[ai-minutes] 邀请码注册未完成，面板将无法访问数据')
  }

  dingtalkIdentity().then((id) => { dtIdentity = id })
  ensureDevice()
  const identitySrv = serveIdentity(() => ({
    ...(device ? { owner: device.owner, name: device.name || (dtIdentity && dtIdentity.name) || '' } : dtIdentity),
    token: device ? device.token : null,
    needsInvite: !device,
  }), identityPort, port)

  ctx.effect(() => {
    start()
    return () => {
      disposed = true
      if (timer) clearTimeout(timer)
      if (child) { try { child.kill() } catch { /* ignore */ } }
      try { identitySrv.close() } catch { /* ignore */ }
    }
  })
}
