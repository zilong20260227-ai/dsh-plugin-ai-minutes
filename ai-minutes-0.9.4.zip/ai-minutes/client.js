window.__ModuleLoader__.load({
  id: '@sygj/plugin-ai-minutes',
  factory(require) {
    const React = require('react');
    // 抽屉要压在宿主左侧栏之上：槽位容器处在低 z-index 的层叠上下文里，
    // 子元素再高的 z-index 也逃不出去，所以尽量用 portal 挂到 body
    let createPortal = null;
    try {
      const rd = require('react-dom');
      createPortal = rd && rd.createPortal ? rd.createPortal : null;
    } catch (e) { createPortal = null; }
    const h = React.createElement;
    // 服务地址：默认 8077；宿主若配了别的端口，会通过 8099/owner 一起下发 apiPort
    let API_PORT = 8077;
    let deviceToken = null;
    const BASE_OF = (p) => `http://127.0.0.1:${p}`;
    const BASE = BASE_OF(API_PORT);
    const TOKEN_KEY = 'aim_token';
    const authHeaders = () => {
      const t = (window.localStorage && window.localStorage.getItem(TOKEN_KEY)) || '';
      const dev = deviceToken ? { 'x-aim-device': deviceToken } : {};
      return { ...(t ? { authorization: `Bearer ${t}` } : {}), ...dev };
    };
    // 每个安装实例一个 owner id：第一次打开时生成，之后固定在 localStorage。
    // 服务端按它隔离数据，因此新装的人看到的是空列表；本机老数据挂在 local-default 下。
    const OWNER_KEY = 'aim_owner';
    const IDENTITY_URL = 'http://127.0.0.1:8099/owner';
    // 身份优先取钉钉账号（插件宿主从 dws 读 corpId+userId 后经本机回环端口给出），
    // 拿不到才退回一个本机随机 id。前者同一个人换机器/重装仍是同一份数据。
    let ownerName = '';
    try { ownerName = (window.localStorage && window.localStorage.getItem('aim_owner_name')) || ''; } catch (e) { /* ignore */ }
    let ownerId = (() => {
      try {
        const ls = window.localStorage;
        const v = ls && ls.getItem(OWNER_KEY);
        if (v) return v;
        const gen = 'u_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
        if (ls) ls.setItem(OWNER_KEY, gen);
        return gen;
      } catch (e) {
        return 'local-default';
      }
    })();
    const ownerReady = (async () => {
      try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 2000);
        const r = await fetch(IDENTITY_URL, { signal: ctrl.signal });
        clearTimeout(t);
        const d = await r.json();
        if (d && typeof d.apiPort === 'number' && d.apiPort > 0 && d.apiPort !== API_PORT) {
          API_PORT = d.apiPort;
        }
        if (d && d.token) {
          deviceToken = d.token;
        }
        if (d && d.owner) {
          ownerId = d.owner;
          try { window.localStorage.setItem(OWNER_KEY, ownerId); } catch (e) { /* ignore */ }
          try { window.localStorage.setItem('aim_owner_name', d.name || ''); } catch (e) { /* ignore */ }
        }
      } catch (e) { /* 宿主没起或超时：用本机随机 id */ }
      return ownerId;
    })();
    const apiFetch = (path, init) => fetch(`${BASE_OF(API_PORT)}${path}`, {
      ...(init || {}),
      headers: {
        'x-aim-owner': ownerId,
        ...authHeaders(),
        ...((init && init.headers) || {}),
      },
    });

    const apiBase = () => BASE_OF(API_PORT);

    const fmtWhen = (ts) => {
      if (!ts) return '';
      const d = new Date(ts * 1000);
      const p = (n) => String(n).padStart(2, '0');
      return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
    };
    const fmtDur = (ms) => {
      const s = Math.max(0, Math.round((ms || 0) / 1000));
      return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
    };
    const mmss = (ms) => {
      const s = Math.max(0, Math.round((ms || 0) / 1000));
      return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
    };

    const pcmToWav = (chunks, sampleRate) => {
      let total = 0;
      for (const c of chunks) total += c.length;
      const buffer = new ArrayBuffer(44 + total * 2);
      const view = new DataView(buffer);
      const writeStr = (o, t) => { for (let i = 0; i < t.length; i += 1) view.setUint8(o + i, t.charCodeAt(i)); };
      writeStr(0, 'RIFF');
      view.setUint32(4, 36 + total * 2, true);
      writeStr(8, 'WAVE');
      writeStr(12, 'fmt ');
      view.setUint32(16, 16, true);
      view.setUint16(20, 1, true);
      view.setUint16(22, 1, true);
      view.setUint32(24, sampleRate, true);
      view.setUint32(28, sampleRate * 2, true);
      view.setUint16(32, 2, true);
      view.setUint16(34, 16, true);
      writeStr(36, 'data');
      view.setUint32(40, total * 2, true);
      let off = 44;
      for (const c of chunks) {
        for (let i = 0; i < c.length; i += 1) {
          const v = Math.max(-1, Math.min(1, c[i]));
          view.setInt16(off, v < 0 ? v * 0x8000 : v * 0x7fff, true);
          off += 2;
        }
      }
      return new Blob([view], { type: 'audio/wav' });
    };

    // ===== 模块级：上传 =====
    // 放到组件外面，录音结束/切页面时都能用，不依赖某个组件的 setState
    const uploadAudio = async (file, onProgress) => {
      const say = (t) => { try { onProgress && onProgress(t); } catch (e) { /* ignore */ } };
      if (!file) return null;
      try {
        say('创建听记…');
        const r = await apiFetch('/v1/minutes', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ title: file.name.replace(/\.[^.]+$/, '').slice(0, 80) }),
        });
        if (!r.ok) throw new Error(`create HTTP ${r.status}`);
        const { id } = await r.json();
        const CH = 5 * 1024 * 1024;
        const total = Math.max(1, Math.ceil(file.size / CH));
        for (let i = 0; i < total; i += 1) {
          say(`上传分片 ${i + 1}/${total}`);
          const buf = await file.slice(i * CH, (i + 1) * CH).arrayBuffer();
          const rr = await apiFetch(`/v1/minutes/${id}/chunks/${i}`, { method: 'PUT', body: buf });
          if (!rr.ok) throw new Error(`chunk ${i} HTTP ${rr.status}`);
        }
        say('收尾转码…');
        const rc = await apiFetch(`/v1/minutes/${id}/complete`, { method: 'POST' });
        if (!rc.ok) throw new Error(`complete HTTP ${rc.status}`);
        say('已入队，转写中…');
        return id;
      } catch (e) {
        say(`上传失败：${e.message}`);
        return null;
      }
    };

    // ===== 模块级录音单例 =====
    // 组件卸载（用户切到别的面板）时录音不能停，所以状态必须活在组件外面。
    const Recorder = (() => {
      let audio = { chunks: [], ctx: null, stream: null, node: null,
                    startedAt: 0, pausedMs: 0, pausedAt: 0 };
      let ws = null;
      let timer = null;
      let handlers = {};
      let state = { active: false, paused: false, secs: 0, liveText: '',
                    mode: true, pageVisible: false, wsState: 'idle',
                    expanded: false };   // true=在看完整的录音界面，false=只有浮条
      const listeners = new Set();
      const emit = () => {
        const snap = { ...state };
        listeners.forEach((fn) => { try { fn(snap); } catch (e) { /* ignore */ } });
      };
      const say = (t) => { try { handlers.onProgress && handlers.onProgress(t); } catch (e) { /* ignore */ } };

      const tick = () => {
        if (!state.active) return;
        const p = audio.pausedAt ? Date.now() - audio.pausedAt : 0;
        state.secs = Math.round((Date.now() - audio.startedAt - (audio.pausedMs || 0) - p) / 1000);
        emit();
      };

      const teardown = async () => {
        if (audio.node) { try { audio.node.disconnect(); } catch (e) { /* ignore */ } }
        if (audio.ctx) { try { await audio.ctx.close(); } catch (e) { /* ignore */ } }
        if (audio.stream) { audio.stream.getTracks().forEach((t) => t.stop()); }
        if (timer) { clearInterval(timer); timer = null; }
        if (ws) { try { ws.close(); } catch (e) { /* ignore */ } ws = null; }
        audio = { chunks: [], ctx: null, stream: null, node: null, startedAt: 0, pausedMs: 0, pausedAt: 0 };
      };

      const api = {
        on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
        snapshot() { return { ...state }; },
        setPageVisible(v) {
          state.pageVisible = v;
          if (!v) state.expanded = false;   // 离开页面就收起，回来时只看到浮条
          emit();
        },
        setExpanded(v) { state.expanded = !!v; emit(); },
        getActive() { return state.active; },

        async start({ liveMode, onProgress, onDone }) {
          if (state.active) return;
          handlers = { onProgress, onDone };
          try {
            const stream = await navigator.mediaDevices.getUserMedia({
              audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true },
            });
            const ctx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
            const src = ctx.createMediaStreamSource(stream);
            const node = ctx.createScriptProcessor(4096, 1, 1);
            const chunks = [];
            node.onaudioprocess = (ev) => {
              if (audio.pausedAt) return;
              const buf = ev.inputBuffer.getChannelData(0);
              chunks.push(new Float32Array(buf));
              if (ws && ws.readyState === 1) {
                const pcm = new Int16Array(buf.length);
                for (let i = 0; i < buf.length; i += 1) {
                  const v = Math.max(-1, Math.min(1, buf[i]));
                  pcm[i] = v < 0 ? v * 0x8000 : v * 0x7fff;
                }
                ws.send(pcm.buffer);
              }
            };
            src.connect(node);
            node.connect(ctx.destination);

            if (liveMode) {
              const token = (window.localStorage && window.localStorage.getItem(TOKEN_KEY)) || '';
              const wsUrl = apiBase().replace(/^http/, 'ws') + '/v1/stream'
                + (deviceToken ? `?d=${encodeURIComponent(deviceToken)}` : '')
                + `?o=${encodeURIComponent(ownerId)}`
                + (token ? `&token=${encodeURIComponent(token)}` : '');
              ws = new WebSocket(wsUrl);
              ws.binaryType = 'arraybuffer';
              ws.onmessage = (ev) => {
                try {
                  const m = JSON.parse(ev.data);
                  if (m.type === 'partial') { state.liveText = m.text || ''; emit(); }
                  else if (m.type === 'final') {
                    state.liveText = m.text || '';
                    state.active = false;
                    emit();
                    say(m.minutes_id ? '已生成听记' : '结束（无内容）');
                    if (handlers.onDone) handlers.onDone();
                  } else if (m.type === 'error') say(`流式错误：${m.message}`);
                } catch (e) { /* ignore */ }
              };
              state.wsState = 'connecting';
              ws.onopen = () => {
                state.wsState = 'open';
                emit();
                if (token) ws.send(JSON.stringify({ type: 'auth', token }));
              };
              ws.onerror = () => { state.wsState = 'failed'; emit(); };
              ws.onclose = () => {
                if (state.active) { state.wsState = 'failed'; emit(); }
              };
            }

            audio = { chunks, ctx, stream, node, startedAt: Date.now(), pausedMs: 0, pausedAt: 0 };
            Object.assign(state, { active: true, paused: false, secs: 0, liveText: '',
                                   mode: !!liveMode, expanded: true });
            timer = setInterval(tick, 1000);
            emit();
            say(liveMode ? '实时转写中…' : '录音中…');
          } catch (e) {
            say(`无法录音：${e.message}（需要麦克风权限）`);
          }
        },

        togglePause() {
          if (!state.active) return;
          if (audio.pausedAt) {
            audio.pausedMs = (audio.pausedMs || 0) + (Date.now() - audio.pausedAt);
            audio.pausedAt = 0;
            state.paused = false;
          } else {
            audio.pausedAt = Date.now();
            state.paused = true;
          }
          emit();
        },

        async stop() {
          if (!state.active) return;
          const chunks = audio.chunks;
          const live = state.mode;
          state.active = false;
          state.paused = false;
          state.expanded = false;
          emit();
          if (live) {
            if (ws) { try { ws.send(JSON.stringify({ type: 'end' })); } catch (e) { /* ignore */ } }
            if (audio.node) { try { audio.node.disconnect(); } catch (e) { /* ignore */ } }
            if (audio.ctx) { try { await audio.ctx.close(); } catch (e) { /* ignore */ } }
            if (audio.stream) { audio.stream.getTracks().forEach((t) => t.stop()); }
            if (timer) { clearInterval(timer); timer = null; }
            audio = { chunks: [], ctx: null, stream: null, node: null, startedAt: 0, pausedMs: 0, pausedAt: 0 };
            say('收尾中…');
            setTimeout(() => { ws = null; }, 1500);
            return;
          }
          if (!chunks.length) { await teardown(); say('没有录到声音'); return; }
          const wav = pcmToWav(chunks, 16000);
          await teardown();
          const stamp = new Date().toISOString().slice(0, 16).replace('T', ' ');
          const id = await uploadAudio(new File([wav], `录音 ${stamp}.wav`, { type: 'audio/wav' }), say);
          if (id && handlers.onDone) handlers.onDone();
        },

        async cancel() {
          if (!state.active) return;
          state.active = false;
          state.paused = false;
          state.liveText = '';
          emit();
          await teardown();
          say('已取消本次听记');
        },
      };
      // 调试把手：线上排查时可以看录音状态、手动停掉（只读状态 + 同一套操作）
      try { window.__aimRecorder = api; } catch (e) { /* ignore */ }
      return api;
    })();

    // 设计取色自得到大脑（#1d2129 主文字 / #8a8f99 次文字 / #e5e6ea 分割线 / #f5f7fa 底 / #ff6a41 强调 / #e8e0ff 语音紫）
    const T = {
      ink: '#1d2129', ink2: '#292d34', gray: '#8a8f99', line: '#e5e6ea',
      bg: '#ffffff', soft: '#f5f7fa', accent: '#ff6a41', violet: '#e8e0ff',
    };
    const FONT = '-apple-system, BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", sans-serif';

    // 收起态：贴在左侧边缘的竖排小标签
    const pill = {
      writingMode: 'vertical-rl', textOrientation: 'mixed', cursor: 'pointer',
      border: `1px solid ${T.line}`, borderLeft: 'none', borderRadius: '0 12px 12px 0',
      padding: '14px 7px', background: T.bg, color: T.ink, fontSize: 13, fontWeight: 500,
      boxShadow: '0 8px 24px rgba(29,33,41,.14)', fontFamily: FONT,
      display: 'flex', alignItems: 'center', gap: 6, letterSpacing: 1,
    };
    // 展开态：左侧全高抽屉
    const card = {
      position: 'fixed', left: 0, top: 0, bottom: 0, zIndex: 2147483000, width: 432,
      background: T.bg, color: T.ink, borderRight: `1px solid ${T.line}`,
      boxShadow: '12px 0 40px rgba(29,33,41,.14)', display: 'flex', flexDirection: 'column',
      overflow: 'hidden', fontFamily: FONT,
    };
    const ghost = {
      border: `1px solid ${T.line}`, background: T.bg, color: T.ink2, borderRadius: 8,
      padding: '5px 10px', fontSize: 12, cursor: 'pointer', fontFamily: FONT,
    };
    const primary = {
      border: 'none', background: T.accent, color: '#fff', borderRadius: 999,
      padding: '10px 22px', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: FONT,
    };
    const heroMic = {
      width: 64, height: 64, borderRadius: 999, border: 'none', cursor: 'pointer',
      background: `radial-gradient(circle at 30% 25%, #ffffff 0%, ${T.violet} 70%)`,
      fontSize: 26, display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: '0 8px 20px rgba(160,140,220,.35)',
    };

    function Minutes() {
      const [open] = React.useState(true);   // 页面模式：由侧栏菜单控制显隐，不再有展开/收起
      const [list, setList] = React.useState([]);
      const [cursor, setCursor] = React.useState(null);
      const [listW, setListW] = React.useState(() => {
        try { return Number(window.localStorage.getItem('aim_list_w')) || 340; } catch (e) { return 340; }
      });
      const dragRef = React.useRef(null);
      const startDrag = (e) => {
        e.preventDefault();
        dragRef.current = { x: e.clientX, w: listW };
        const onMove = (ev) => {
          const d = dragRef.current;
          if (!d) return;
          const next = Math.min(680, Math.max(220, d.w + (ev.clientX - d.x)));
          setListW(next);
        };
        const onUp = () => {
          dragRef.current = null;
          window.removeEventListener('mousemove', onMove);
          window.removeEventListener('mouseup', onUp);
          try { window.localStorage.setItem('aim_list_w', String(listW)); } catch (er) { /* ignore */ }
        };
        window.addEventListener('mousemove', onMove);
        window.addEventListener('mouseup', onUp);
      };
      const [q, setQ] = React.useState('');
      const [sel, setSel] = React.useState(null);
      const [err, setErr] = React.useState('');
      const audioRef = React.useRef(null);
      const fileRef = React.useRef(null);
      const [progress, setProgress] = React.useState('');
      const [hits, setHits] = React.useState([]);
      const pendingSeek = React.useRef(null);
      // 把纪要里的 [mm:ss] 变成可点击的跳转点（闭包内定义，才能拿到 audioRef）
      const withJump = (text, space) => {
        if (!text) return null;
        const parts = [];
        const re = /\[(\d{1,2}):(\d{2})\]/g;
        let last = 0;
        let m;
        let key = 0;
        while ((m = re.exec(text)) !== null) {
          if (m.index > last) parts.push(text.slice(last, m.index));
          const secs = Number(m[1]) * 60 + Number(m[2]);
          parts.push(h('span', {
            key: 'j' + (key += 1),
            style: { color: '#0a7', cursor: 'pointer', textDecoration: 'underline dotted' },
            onClick: () => {
              const a = audioRef.current;
              if (!a) return;
              a.currentTime = secs;
              a.play().catch(() => {});
            },
          }, m[0]));
          last = m.index + m[0].length;
        }
        if (last < text.length) parts.push(text.slice(last));
        return h('pre', { key: 'sum', style: space }, parts);
      };
      // 录音状态活在模块单例里：切到别的面板（本组件卸载）录音不中断
      const [recState, setRecState] = React.useState(Recorder.snapshot());
      React.useEffect(() => {
        Recorder.setPageVisible(true);
        const off = Recorder.on(setRecState);
        return () => { Recorder.setPageVisible(false); off(); };
      }, []);
      const recording = recState.active;
      const recSecs = recState.secs;
      const paused = recState.paused;
      const liveText = recState.liveText;
      const [liveMode, setLiveMode] = React.useState(true);
      const [tab, setTab] = React.useState('summary');
      const [cur, setCur] = React.useState(0);
      const [dur, setDur] = React.useState(0);
      const [rate, setRate] = React.useState(1);
      const [analysis, setAnalysis] = React.useState(null);
      const [tplOpen, setTplOpen] = React.useState(false);
      const [tpls, setTpls] = React.useState([]);
      const [models, setModels] = React.useState([]);
      const [regenBusy, setRegenBusy] = React.useState(false);

      const liveRef = React.useRef(null);
      React.useEffect(() => {
        if (liveRef.current) liveRef.current.scrollTop = liveRef.current.scrollHeight;
      }, [liveText]);

      React.useEffect(() => {
        if (!open || tpls.length) return;
        (async () => {
          try {
            const [t, m] = await Promise.all([
              apiFetch('/v1/templates').then((r) => r.json()),
              apiFetch('/v1/models').then((r) => r.json()),
            ]);
            setTpls(t.items || []);
            setModels(m.items || []);
          } catch (e) { /* 失败就只显示默认文案 */ }
        })();
      }, [open, tpls.length]);

      React.useEffect(() => {
        if (!sel || tab !== 'analysis' || analysis) return;
        let alive = true;
        (async () => {
          try {
            const [ins, mm] = await Promise.all([
              apiFetch(`/v1/minutes/${sel.id}/insights`).then((r) => r.json()),
              apiFetch(`/v1/minutes/${sel.id}/mindmap`).then((r) => r.json()),
            ]);
            if (alive) setAnalysis({ insights: ins.insights, mindmap: mm.mindmap });
          } catch (e) { if (alive) setAnalysis({}); }
        })();
        return () => { alive = false; };
      }, [sel, tab, analysis]);

      const loadList = React.useCallback(async (more) => {
        await ownerReady;
        try {
          const params = new URLSearchParams({ limit: '20' });
          if (q.trim()) params.set('q', q.trim());
          if (more && cursor) params.set('cursor', cursor);
          const r = await apiFetch(`/v1/minutes?${params}`, { cache: 'no-store' });
          if (!r.ok) throw new Error(`HTTP ${r.status}`);
          const d = await r.json();
          setList(more ? [...list, ...(d.items || [])] : (d.items || []));
          setCursor(d.next_cursor || null);
          setErr('');
        } catch (e) {
          setErr(`连不上听记服务（${e.message}），确认本地隧道 8077 是否在跑`);
        }
      }, [q, cursor, list]);

      React.useEffect(() => {
        if (!open) return;
        loadList(false);
        const t = setInterval(() => loadList(false), 8000);
        return () => clearInterval(t);
      }, [open, loadList]);

      const upload = async (file) => {
        const id = await uploadAudio(file, (t) => setProgress(t));
        if (id) await loadList(false);
      };

      const runSearch = async () => {
        const term = q.trim();
        if (term.length < 3) { setHits([]); loadList(false); return; }
        try {
          const r = await apiFetch(`/v1/search?q=${encodeURIComponent(term)}&limit=30`);
          if (!r.ok) throw new Error(`HTTP ${r.status}`);
          const d = await r.json();
          setHits(d.hits || []);
          setErr('');
        } catch (e) {
          setErr(`检索失败：${e.message}`);
        }
      };

      // 下面四个只做转发，真正的逻辑在模块级 Recorder 里（切页面不中断）
      const togglePause = () => Recorder.togglePause();
      const stopRecording = () => Recorder.stop();
      const cancelRecording = () => Recorder.cancel();
      const startRecording = () => Recorder.start({
        liveMode,
        onProgress: (t) => setProgress(t),
        onDone: () => loadList(false),
      });

      const openHit = async (hit) => {
        pendingSeek.current = (hit.start_ms || 0) / 1000;
        await openOne(hit.minutes_id);
      };

      const openOne = async (id) => {
        try {
          const r = await apiFetch(`/v1/minutes/${id}`, { cache: 'no-store' });
          const d = await r.json();
          setSel(d);
          setErr('');
        } catch (e) {
          setErr(`读取失败：${e.message}`);
        }
      };

      // ===== 页面头部 =====
      const header = h('div', {
        key: 'hd',
        style: {
          display: 'flex', alignItems: 'center', gap: 10, padding: '18px 24px 14px',
          borderBottom: `1px solid ${T.line}`, flexShrink: 0,
        },
      },
        h('span', { style: { fontSize: 18, fontWeight: 600, letterSpacing: 0.2, color: T.ink } }, 'AI听记'),
        h('span', { style: { fontSize: 12.5, color: T.gray, marginTop: 2 } }, '录音自动转写、出纪要与章节'),
        h('span', { style: { flex: 1 } }),
        h('button', {
          style: { ...primary, padding: '8px 16px', fontSize: 13, borderRadius: 999 },
          onClick: startRecording,
        }, '● 开始录音'),
        h('button', {
          style: { ...ghost, padding: '8px 14px', fontSize: 13 },
          onClick: () => fileRef.current && fileRef.current.click(),
        }, '上传音视频'));

      // ===== 录音区（未在详情时显示）=====
      // ===== 录音页（整屏转写 + 底部操作条，参照得到大脑）=====
      const recArea = recording
        ? h('div', { key: 'rec', style: { display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 } },
            h('div', {
              ref: liveRef,
              style: { flex: 1, minHeight: 0, overflow: 'auto', padding: '18px 20px',
                       fontSize: 17, lineHeight: '32px', color: T.ink, letterSpacing: 0.2 },
            },
              liveText
                ? h('div', null, liveText)
                : h('div', { style: { color: T.gray, fontSize: 14 } },
                    !recState.mode ? '实时转写已关闭，结束后统一转写'
                      : recState.wsState === 'failed' ? '实时转写连接失败（结束后仍会整体转写）'
                      : recState.wsState === 'connecting' ? '连接实时转写…'
                      : recState.wsState === 'open' ? '正在听……' : '准备中…')),
            h('div', { style: { padding: '10px 20px 18px', flexShrink: 0, borderTop: `1px solid ${T.line}` } },
              h('div', {
                style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10,
                         fontSize: 12.5, color: T.gray, fontVariantNumeric: 'tabular-nums' },
              },
                h('span', { style: { display: 'inline-flex', gap: 2, alignItems: 'flex-end', height: 12 } },
                  [0, 1, 2, 3].map((i) => h('span', {
                    key: i,
                    style: { width: 2.5, borderRadius: 2, background: T.accent,
                             height: 4 + Math.abs(Math.sin(recSecs * 1.6 + i)) * 8 },
                  }))),
                h('span', null, `${String(Math.floor(recSecs / 60)).padStart(2, '0')}:${String(recSecs % 60).padStart(2, '0')} / 60:00`),
                h('span', { style: { flex: 1 } }),
                h('span', {
                  style: { fontSize: 11.5,
                           color: recState.wsState === 'open' ? '#22a06b'
                             : recState.wsState === 'failed' ? '#e5484d' : T.gray },
                }, recState.mode
                  ? (recState.wsState === 'open' ? '● 实时转写已连接'
                      : recState.wsState === 'failed' ? '● 实时转写断开' : '● 连接中…')
                  : '● 仅录音')),
              h('div', { style: { display: 'flex', alignItems: 'center' } },
                h('button', {
                  style: { ...ghost, border: 'none', color: T.gray, fontSize: 15, padding: '8px 4px' },
                  onClick: cancelRecording,
                }, '取消'),
                h('button', {
                  style: { ...ghost, border: 'none', color: T.gray, fontSize: 13, padding: '8px 6px' },
                  onClick: () => Recorder.setExpanded(false),
                  title: '收起成小浮条，录音继续',
                }, '收起'),
                h('span', { style: { flex: 1 } }),
                h('button', {
                  style: { width: 52, height: 52, borderRadius: 999, border: 'none', cursor: 'pointer',
                           background: '#f45b69', color: '#fff', fontSize: 20 },
                  onClick: togglePause, title: paused ? '继续' : '暂停',
                }, paused ? '▶' : '⏸'),
                h('span', { style: { flex: 1 } }),
                h('button', {
                  style: { ...ghost, border: 'none', fontSize: 15, fontWeight: 600, padding: '8px 4px' },
                  onClick: stopRecording,
                }, '完成'))))
        : h('div', { key: 'idle', style: { padding: '26px 18px 18px', textAlign: 'center', flexShrink: 0 } },
            h('button', {
              style: { ...heroMic, margin: '0 auto' },
              onClick: startRecording, title: '开始录音',
            }, '🎙'),
            h('div', { style: { marginTop: 14, fontSize: 15, fontWeight: 500 } }, '点击开始录音'),
            h('div', { style: { marginTop: 6, fontSize: 12.5, color: T.gray, lineHeight: '18px' } },
              '结束后自动生成逐字稿与总结'),
            h('div', { style: { marginTop: 16, display: 'flex', gap: 8, justifyContent: 'center' } },
              h('button', { style: ghost, onClick: () => fileRef.current && fileRef.current.click() }, '上传音视频'),
              h('label', { style: { ...ghost, display: 'inline-flex', alignItems: 'center', gap: 4 } },
                h('input', {
                  type: 'checkbox', checked: liveMode, disabled: recording,
                  onChange: (e) => setLiveMode(e.target.checked),
                }), '实时转写')));

      // ===== 列表 =====
      const statusText = (m) => ({
        ready: '已就绪', transcribing: '转写中', uploaded: '排队中',
        failed: '失败', rejected: '已拒绝', created: '待上传',
      }[m.status] || m.status);

      const listBody = hits.length
        ? h('div', { style: { overflow: 'hidden' } }, [
            h('div', { key: 'ht', style: { padding: '10px 18px 4px', fontSize: 12, color: T.gray } },
              `全文命中 ${hits.length} 条`),
            ...hits.map((hit) => h('div', {
              key: `${hit.minutes_id}-${hit.seg_idx}`,
              style: { padding: '10px 18px', borderTop: `1px solid ${T.line}`, cursor: 'pointer' },
              onClick: () => openHit(hit),
              onMouseEnter: (e) => { e.currentTarget.style.background = T.soft; },
              onMouseLeave: (e) => { e.currentTarget.style.background = 'transparent'; },
            },
              h('div', { style: { fontSize: 13.5, lineHeight: '20px' } }, hit.snip),
              h('div', { style: { fontSize: 12, color: T.gray, marginTop: 2 } },
                `${hit.title || hit.minutes_id} · ${mmss(hit.start_ms)}`))),
          ])
        : h('div', { style: { overflow: 'hidden' } }, list.length
            ? list.map((m) => h('div', {
                key: m.id,
                style: { padding: '11px 16px', cursor: 'pointer',
                       borderTop: `1px solid ${T.line}`,
                       borderLeft: sel && sel.id === m.id ? '3px solid #2b6cff' : '3px solid transparent',
                       background: sel && sel.id === m.id ? T.bg : 'transparent' },
                onClick: () => openOne(m.id),
                onMouseEnter: (e) => { e.currentTarget.style.background = T.bg; },
                onMouseLeave: (e) => { e.currentTarget.style.background = 'transparent'; },
              },
                h('div', { style: { display: 'flex', alignItems: 'center', gap: 6 } },
                  h('div', {
                    style: { flex: 1, minWidth: 0, fontSize: 13.5, fontWeight: 600, color: T.ink,
                             overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
                  }, m.title || m.id),
                  h('button', {
                    style: { ...ghost, border: 'none', padding: '1px 4px', fontSize: 12, color: T.gray },
                    title: '删除',
                    onClick: async (e) => {
                      e.stopPropagation();
                      if (!window.confirm(`删除「${m.title || m.id}」？音频和逐字稿都会删掉。`)) return;
                      try {
                        await apiFetch(`/v1/minutes/${m.id}`, { method: 'DELETE' });
                        setProgress('已删除');
                        if (sel && sel.id === m.id) setSel(null);
                        loadList(false);
                      } catch (er) { setProgress(`删除失败：${er.message}`); }
                    },
                  }, '✕'),
                  ['failed', 'uploaded', 'created'].includes(m.status)
                    ? h('button', {
                        style: { ...ghost, border: 'none', padding: '1px 4px', fontSize: 12, color: T.gray },
                        title: '重新转写',
                        onClick: async (e) => {
                          e.stopPropagation();
                          try {
                            await apiFetch(`/v1/minutes/${m.id}/retry`, { method: 'POST' });
                            setProgress('已重新排队转写');
                            loadList(false);
                          } catch (er) { setProgress(`重试失败：${er.message}`); }
                        },
                      }, '↻')
                    : null),
                h('div', {
                  style: { fontSize: 12, color: T.gray, marginTop: 3, lineHeight: '17px',
                           overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
                }, m.description || (m.status === 'failed' && m.error ? m.error : statusText(m))),
                h('div', {
                  style: { fontSize: 11, color: '#a8adb8', marginTop: 4,
                           fontVariantNumeric: 'tabular-nums' },
                }, `${fmtWhen(m.created_at)} · ${fmtDur(m.duration_ms)}`)))
            : h('div', { style: { padding: '28px 18px', textAlign: 'center', color: T.gray, fontSize: 13 } },
                '还没有听记，点右上角开始录音或上传音视频'));

      // ===== 详情 =====
      // 说话人配色（参照钉钉：紫 / 粉 / 青 / 灰）
      const SPK_COLORS = ['#8b7ff0', '#f08fb0', '#5cc9bd', '#9aa2b1', '#f0b26b'];
      const spkColor = (ids, sid) => SPK_COLORS[Math.max(0, ids.indexOf(sid)) % SPK_COLORS.length];
      const speakerIds = sel
        ? Array.from(new Set((sel.segments || []).map((x) => x.speaker_id).filter(Boolean)))
        : [];
      const spkName = (sid) => {
        const named = sel && (sel.speaker_names || {})[sid];
        if (named) return named;
        const i = speakerIds.indexOf(sid);
        return i >= 0 ? `发言人 ${i + 1}` : sid;
      };
      const seekTo = (sec) => {
        const a = audioRef.current;
        if (!a) return;
        a.currentTime = Math.max(0, sec);
        a.play().catch(() => {});
      };

      const tabBtn = (key, label) => h('button', {
        key,
        style: {
          border: 'none', background: 'transparent', cursor: 'pointer', padding: '8px 2px',
          marginRight: 22, fontSize: 14, fontFamily: FONT,
          color: tab === key ? T.ink : T.gray,
          fontWeight: tab === key ? 600 : 400,
          borderBottom: tab === key ? `2px solid #2b6cff` : '2px solid transparent',
        },
        onClick: () => setTab(key),
      }, label);

      // ---------- 播放器 ----------
      const renderPlayer = () => sel && h('div', {
        key: 'player',
        style: { margin: '10px 16px 6px', padding: '12px 14px', background: '#f7f8fb',
                 borderRadius: 14, flexShrink: 0 },
      },
        h('div', { style: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 11.5,
                            color: T.gray, fontVariantNumeric: 'tabular-nums' } },
          h('span', null, mmss(cur * 1000)),
          h('input', {
            type: 'range', min: 0, max: Math.max(1, dur), step: 0.1, value: cur,
            onChange: (e) => { const a = audioRef.current; const v = Number(e.target.value); setCur(v); if (a) a.currentTime = v; },
            style: { flex: 1, accentColor: '#2b6cff', cursor: 'pointer' },
          }),
          h('span', null, mmss(dur * 1000))),
        h('div', { style: { display: 'flex', alignItems: 'center', gap: 10, marginTop: 6 } },
          speakerIds.length
            ? h('div', { style: { display: 'flex', alignItems: 'center', gap: 4 } },
                h('span', { style: { fontSize: 11.5, color: T.gray, marginRight: 2 } }, '发言人'),
                speakerIds.slice(0, 4).map((sid, i) =>
                  h('button', {
                    key: sid, title: spkName(sid),
                    style: { width: 20, height: 20, borderRadius: 999, border: 'none', cursor: 'pointer',
                             background: spkColor(speakerIds, sid), color: '#fff', fontSize: 11,
                             lineHeight: '20px', padding: 0 },
                    onClick: () => {
                      const seg = (sel.segments || []).find((x) => x.speaker_id === sid);
                      if (seg) seekTo((seg.start_ms || 0) / 1000);
                    },
                  }, String(i + 1))))
            : null,
          h('span', { style: { flex: 1 } }),
          h('button', { style: { ...ghost, border: 'none', fontSize: 13 },
                        onClick: () => seekTo(Math.max(0, cur - 15)) }, '↺15'),
          h('button', {
            style: { ...ghost, border: 'none', fontSize: 16, minWidth: 28 },
            onClick: () => {
              const a = audioRef.current;
              if (!a) return;
              if (a.paused) a.play().catch(() => {}); else a.pause();
            },
          }, h('span', null, (audioRef.current && !audioRef.current.paused) ? '⏸' : '▶')),
          h('button', { style: { ...ghost, border: 'none', fontSize: 13 },
                        onClick: () => seekTo(cur + 15) }, '15↻'),
          h('button', {
            style: { ...ghost, border: 'none', fontSize: 12, minWidth: 42 },
            onClick: () => {
              const next = rate === 1 ? 1.5 : rate === 1.5 ? 2 : 1;
              setRate(next);
              if (audioRef.current) audioRef.current.playbackRate = next;
            },
          }, `${rate.toFixed(1)}x`)),
        h('audio', {
          key: 'audio', ref: (el) => { audioRef.current = el; }, preload: 'metadata',
          src: `${apiBase()}/v1/minutes/${sel.id}/audio?o=${encodeURIComponent(ownerId)}`, style: { display: 'none' },
          onLoadedMetadata: (e) => {
            setDur(e.currentTarget.duration || 0);
            if (pendingSeek.current != null) {
              e.currentTarget.currentTime = pendingSeek.current;
              pendingSeek.current = null;
            }
          },
          onTimeUpdate: (e) => setCur(e.currentTarget.currentTime || 0),
        }));

      // ---------- 四个 tab 的内容 ----------
      const renderMeta = () => h('div', {
        key: 'meta',
        style: { fontSize: 12.5, color: T.gray, lineHeight: '22px', margin: '4px 0 10px',
                 paddingLeft: 10, borderLeft: `2px solid ${T.line}` },
      },
        h('div', null, `主题：${sel.title || ''}`),
        h('div', null, `时间：${fmtWhen(sel.created_at)}`),
        h('div', null, `参与人：${speakerIds.map(spkName).join('、') || '—'}`),
        h('div', null, `模板：${((tpls.find((x) => x.id === sel.template) || {}).title) || sel.template}`
          + `　模型：${((models.find((m) => m.id === sel.model_used) || {}).label) || sel.model_used || '默认'}`));

      const renderTranscript = () => h('div', { style: { padding: '4px 16px 16px' } },
        (sel.segments || []).map((seg) => h('div', {
          key: seg.idx,
          style: { display: 'flex', gap: 8, marginBottom: 14 },
          onClick: () => seekTo((seg.start_ms || 0) / 1000),
          onMouseEnter: (e) => { e.currentTarget.style.opacity = 0.75; },
          onMouseLeave: (e) => { e.currentTarget.style.opacity = 1; },
        },
          h('div', {
            style: { width: 22, height: 22, borderRadius: 6, flexShrink: 0, marginTop: 1,
                     background: spkColor(speakerIds, seg.speaker_id || ''), color: '#fff',
                     fontSize: 11, lineHeight: '22px', textAlign: 'center' },
          }, seg.speaker_id ? String(speakerIds.indexOf(seg.speaker_id) + 1) : '·'),
          h('div', { style: { flex: 1, minWidth: 0 } },
            h('div', { style: { fontSize: 12, color: T.gray, marginBottom: 3 } },
              `${seg.speaker_id ? spkName(seg.speaker_id) : '未知'} ${mmss(seg.start_ms)}`),
            h('div', { style: { fontSize: 14.5, lineHeight: '26px', color: T.ink } }, seg.text)))));

      const runRegen = async (tplId, modelId) => {
        const useTpl = tplId || sel.template || 'meeting-weekly';
        const useModel = modelId || sel.model_used || undefined;
        setRegenBusy(true);
        setTplOpen(false);
        setProgress(`重新生成中…（${((tpls.find((x) => x.id === useTpl) || {}).title) || useTpl}`
          + `${useModel ? ' · ' + ((models.find((m) => m.id === useModel) || {}).label || useModel) : ''}）`);
        const before = (sel.artifacts && sel.artifacts.summary) || '';
        try {
          await apiFetch(`/v1/minutes/${sel.id}/regen`, {
            method: 'POST', headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ template: useTpl, model: useModel }),
          });
          for (let i = 0; i < 40; i += 1) {
            await new Promise((r) => setTimeout(r, 3000));
            const fresh = await apiFetch(`/v1/minutes/${sel.id}`).then((x) => x.json());
            if (fresh.artifacts && fresh.artifacts.summary && fresh.artifacts.summary !== before) {
              setSel(fresh);
              setProgress('纪要已重新生成');
              break;
            }
            if (fresh.status === 'failed' && fresh.error) { setProgress(`生成失败：${fresh.error}`); break; }
          }
        } catch (e) { setProgress(`重新生成失败：${e.message}`); }
        setRegenBusy(false);
      };

      // 主题模板选择：钉钉是「弹层 + 九宫格卡片」，这里对齐它的形态
      const renderTpl = () => h('div', { key: 'tpl', style: { marginBottom: 12 } },
        h('button', {
          style: { display: 'inline-flex', alignItems: 'center', gap: 6, padding: '6px 14px',
                   border: `1px solid ${T.line}`, borderRadius: 999, fontSize: 12.5, color: T.ink2,
                   background: T.bg, cursor: 'pointer', fontFamily: FONT },
          onClick: () => setTplOpen(!tplOpen),
        },
          `主题模板：${((tpls.find((x) => x.id === sel.template) || {}).title) || '周会纪要'}`,
          h('span', { style: { color: T.gray } }, '▾')),

        !tplOpen ? null : h('div', {
          key: 'mask',
          style: { position: 'fixed', inset: 0, background: 'rgba(29,33,41,.28)',
                   zIndex: 2147483100, display: 'flex', alignItems: 'center', justifyContent: 'center' },
          onClick: () => setTplOpen(false),
        },
          h('div', {
            onClick: (e) => e.stopPropagation(),
            style: { width: 560, maxHeight: '78vh', overflow: 'auto', background: T.bg,
                     borderRadius: 14, boxShadow: '0 18px 48px rgba(29,33,41,.22)',
                     padding: '16px 18px 14px', fontFamily: FONT },
          },
            h('div', { style: { display: 'flex', alignItems: 'center', marginBottom: 12 } },
              h('span', { style: { fontSize: 14, fontWeight: 600 } }, '选择纪要模板'),
              h('span', { style: { flex: 1 } }),
              h('button', {
                style: { ...ghost, border: 'none', padding: '2px 6px', fontSize: 15, color: T.gray },
                onClick: () => setTplOpen(false),
              }, '✕')),
            // 九宫格：每张卡是模板缩略图 + 标题
            h('div', {
              style: { display: 'grid', gap: 10, gridTemplateColumns: 'repeat(3, 1fr)' },
            },
              tpls.map((t2) => {
                const active = sel.template === t2.id;
                return h('div', {
                  key: t2.id,
                  onClick: () => {
                    setSel({ ...sel, template: t2.id });
                    setTplOpen(false);
                    runRegen(t2.id, sel.model_used);
                  },
                  style: { cursor: 'pointer', borderRadius: 10, padding: 8,
                           border: `1.5px solid ${active ? '#2b6cff' : T.line}`,
                           background: active ? '#f5f8ff' : T.bg },
                },
                  // 缩略图：用三行灰条模拟版式
                  h('div', { style: { background: '#f5f7fa', borderRadius: 6, padding: 8, marginBottom: 6 } },
                    h('div', { style: { height: 5, width: '55%', background: '#d7dbe2', borderRadius: 3, marginBottom: 5 } }),
                    h('div', { style: { display: 'flex', gap: 4 } },
                      [0, 1, 2].map((i) => h('div', {
                        key: i,
                        style: { flex: 1, height: 26, background: '#fff', borderRadius: 4,
                                 border: `1px solid ${T.line}` },
                      })))),
                  h('div', { style: { display: 'flex', alignItems: 'center', gap: 4 } },
                    h('span', { style: { fontSize: 12.5, fontWeight: active ? 600 : 500,
                                         color: active ? '#2b6cff' : T.ink } }, t2.title),
                    active ? h('span', { style: { color: '#2b6cff', fontSize: 11 } }, '✓') : null));
              })),
            // 底部：模型 + 重新生成
            h('div', {
              style: { marginTop: 14, paddingTop: 12, borderTop: `1px solid ${T.line}`,
                       display: 'flex', alignItems: 'center', gap: 8 },
            },
              h('span', { style: { fontSize: 12, color: T.gray, flexShrink: 0 } }, '模型'),
              h('select', {
                value: sel.model_used || (models[0] && models[0].id) || '',
                onChange: (e) => setSel({ ...sel, model_used: e.target.value }),
                style: { flex: 1, fontSize: 12.5, padding: '6px 8px', borderRadius: 8,
                         border: `1px solid ${T.line}`, background: T.bg, color: T.ink },
              }, models.map((m2) => h('option', { key: m2.id, value: m2.id }, m2.label))),
              h('button', {
                style: { ...primary, padding: '7px 16px', fontSize: 12.5, borderRadius: 999,
                         opacity: regenBusy ? 0.6 : 1 },
                onClick: () => runRegen(sel.template, sel.model_used),
              }, regenBusy ? '生成中…' : '重新生成')))));

      // 每套模板一套视觉：主色 + 底色 + 编号块
      // 每套模板一组四色（章节色块循环用），默认组取自钉钉截图实测值
      const DINGTALK4 = [
        ['#0f9b4f', '#eaf9ef'], ['#0f59c4', '#f1f7fe'],
        ['#bc5782', '#fef5f8'], ['#8b673a', '#f8f7f3'],
      ];
      const THEMES = {
        'meeting-weekly': { accent: '#0f9b4f', tint: '#eaf9ef', name: '周会', palette: DINGTALK4 },
        'customer-visit': { accent: '#c2410c', tint: '#fdf0e8', name: '客户拜访',
          palette: [['#c2410c', '#fdf0e8'], ['#b45309', '#fdf6e7'],
                    ['#8b673a', '#f8f7f3'], ['#0f59c4', '#f1f7fe']] },
        retro: { accent: '#0b7f76', tint: '#e6f6f4', name: '复盘',
          palette: [['#0b7f76', '#e6f6f4'], ['#0f59c4', '#f1f7fe'],
                    ['#5f6b7a', '#f4f6f8'], ['#8b673a', '#f8f7f3']] },
        interview: { accent: '#6446c8', tint: '#f1edfe', name: '访谈',
          palette: [['#6446c8', '#f1edfe'], ['#0f59c4', '#f1f7fe'],
                    ['#bc5782', '#fef5f8'], ['#5f6b7a', '#f4f6f8']] },
        'one-on-one': { accent: '#1f7a4d', tint: '#e8f6ee', name: '1:1',
          palette: [['#1f7a4d', '#e8f6ee'], ['#0b7f76', '#e6f6f4'],
                    ['#0f59c4', '#f1f7fe'], ['#5f6b7a', '#f4f6f8']] },
        review: { accent: '#9a3412', tint: '#fbeee7', name: '评审',
          palette: [['#9a3412', '#fbeee7'], ['#b45309', '#fdf6e7'],
                    ['#5f6b7a', '#f4f6f8'], ['#0f59c4', '#f1f7fe']] },
      };
      const themeOf = (id) => THEMES[id] || THEMES['meeting-weekly'];
      // 模板变化时立刻换主题色，不用等重新生成
      const activeTheme = () => themeOf(sel && sel.template);

      // 把纪要 markdown 渲染成「编号块 + 卡片」的图文样式
      // 行内：**粗体** / `代码` / [mm:ss] 跳播
      const inline = (text, keyBase) => {
        const out = [];
        const re = /(\*\*[^*]+\*\*|`[^`]+`|\[\d{1,2}:\d{2}\])/g;
        let last = 0; let m; let k = 0;
        while ((m = re.exec(text)) !== null) {
          if (m.index > last) out.push(text.slice(last, m.index));
          const tok = m[0];
          k += 1;
          if (tok.startsWith('**')) {
            out.push(h('b', { key: `${keyBase}-b${k}`, style: { fontWeight: 600, color: T.ink } },
              tok.slice(2, -2)));
          } else if (tok.startsWith('`')) {
            out.push(h('code', {
              key: `${keyBase}-c${k}`,
              style: { background: 'rgba(29,33,41,.06)', borderRadius: 4, padding: '1px 4px',
                       fontSize: '0.94em', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' },
            }, tok.slice(1, -1)));
          } else {
            const [mm, ss] = tok.slice(1, -1).split(':');
            out.push(h('span', {
              key: `${keyBase}-j${k}`,
              style: { color: '#2b6cff', cursor: 'pointer', fontVariantNumeric: 'tabular-nums' },
              onClick: (e) => { e.stopPropagation(); seekTo(Number(mm) * 60 + Number(ss)); },
            }, tok));
          }
          last = m.index + tok.length;
        }
        if (last < text.length) out.push(text.slice(last));
        return out;
      };

      // 把纪要 markdown 解析成「封面 + 章节卡片 + 子卡片 + 表格 + 待办」的结构
      const parseSummary = (md) => {
        const lines = (md || '').split('\n');
        const doc = { title: '', subtitle: '', meta: [], sections: [], insights: [] };
        let sec = null;
        let buf = [];
        let inInsight = false;
        const flushPara = () => {
          const txt = buf.join(' ').trim();
          buf = [];
          if (!txt) return;
          const target = sec ? sec.blocks : null;
          if (!target) {
            if (!doc.title) doc.title = txt;
            else if (!doc.subtitle) doc.subtitle = txt;
            return;
          }
          target.push({ type: 'p', text: txt });
        };
        for (let i = 0; i < lines.length; i += 1) {
          const line = lines[i].replace(/\s+$/, '');
          if (!line.trim()) { flushPara(); continue; }
          if (line.startsWith('# ')) { flushPara(); doc.title = line.slice(2).trim(); continue; }
          if (/^>\s*######\s*AI\s*洞察/.test(line)) {
            flushPara();
            inInsight = true;
            continue;
          }
          if (line.startsWith('> ')) {
            flushPara();
            const body = line.slice(2).trim();
            if (inInsight) {
              const item = body.replace(/^[-*]\s*/, '').trim();
              if (item) doc.insights.push(item);
            } else if (body) {
              doc.meta.push(body);
            }
            continue;
          }
          if (line.startsWith('## ')) {
            flushPara();
            inInsight = false;
            sec = { title: line.slice(3).trim(), blocks: [] };
            doc.sections.push(sec);
            continue;
          }
          if (line.startsWith('### ')) {
            flushPara();
            if (sec) sec.blocks.push({ type: 'sub', title: line.slice(4).trim(), items: [] });
            continue;
          }
          if (/^\s*[-*] \[[ xX]\] /.test(line)) {
            flushPara();
            const done = /\[[xX]\]/.test(line);
            const text = line.replace(/^\s*[-*] \[[ xX]\] /, '');
            const list = sec && sec.blocks.length && sec.blocks[sec.blocks.length - 1].type === 'todo'
              ? sec.blocks[sec.blocks.length - 1] : { type: 'todo', items: [] };
            if (!(sec && sec.blocks[sec.blocks.length - 1] === list)) sec && sec.blocks.push(list);
            list.items.push({ text, done });
            continue;
          }
          if (/^\s*[-*] /.test(line)) {
            flushPara();
            const depth = Math.min(3, Math.floor((line.match(/^\s*/) || [''])[0].length / 4));
            const indent = depth;
            const text = line.replace(/^\s*[-*] /, '');
            const last = sec && sec.blocks[sec.blocks.length - 1];
            const list = last && last.type === 'ul' ? last : { type: 'ul', groups: [] };
            if (!(last === list)) sec && sec.blocks.push(list);
            if (indent === 0) {
              // 一级条目 = 子主题卡片标题
              list.groups.push({ title: text, items: [] });
            } else {
              if (!list.groups.length) list.groups.push({ title: '', items: [] });
              list.groups[list.groups.length - 1].items.push({ text, indent });
            }
            continue;
          }
          if (line.trim().startsWith('|')) {
            flushPara();
            const indented = /^\s{2,}\|/.test(line);
            const rows = [];
            let j = i;
            while (j < lines.length && lines[j].trim().startsWith('|')) {
              const cells = lines[j].trim().replace(/^\|/, '').replace(/\|$/, '').split('|')
                .map((c) => c.trim());
              if (!cells.every((c) => /^:?-{2,}:?$/.test(c) || c === '')) rows.push(cells);
              j += 1;
            }
            i = j - 1;
            if (sec && rows.length) {
              const lastBlk = sec.blocks[sec.blocks.length - 1];
              const lastGroup = indented && lastBlk && lastBlk.type === 'ul' && lastBlk.groups.length
                ? lastBlk.groups[lastBlk.groups.length - 1] : null;
              if (lastGroup) lastGroup.items.push({ type: 'table', rows });
              else sec.blocks.push({ type: 'table', rows });
            }
            continue;
          }
          if (/^---+$/.test(line.trim())) { flushPara(); if (sec) sec.blocks.push({ type: 'hr' }); continue; }
          buf.push(line.trim());
        }
        flushPara();
        return doc;
      };

      // 钉钉「图文纪要」的四种章节主色，按章节序号循环


      // 卡片图标：按标题关键词挑一个线性图标（尽量贴近钉钉的细线风格）
      const iconFor = (title, color) => {
        const t = title || '';
        const pick = /指标|数据|口径|金额/.test(t) ? 'chart'
          : /客户|分配|团队|人/.test(t) ? 'users'
          : /增长|策略|目标|渗透/.test(t) ? 'trend'
          : /风险|问题|质|缺/.test(t) ? 'alert'
          : /工具|部署|培训|系统/.test(t) ? 'cog'
          : /制度|规范|流程/.test(t) ? 'doc'
          : /时间|计划|周期|排期/.test(t) ? 'calendar'
          : /决策|共识|定调|结论/.test(t) ? 'target' : 'chat';
        const paths = {
          chart: ['M4 19h16', 'M7 19v-6', 'M12 19v-10', 'M17 19v-4'],
          users: ['M9 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6z', 'M3 20c0-3 2.7-5 6-5s6 2 6 5', 'M17 11a2.5 2.5 0 1 0 0-5', 'M21 20c0-2.4-1.6-4-3.5-4.4'],
          trend: ['M4 16l5-5 4 3 6-7', 'M15 7h4v4'],
          alert: ['M12 4l9 16H3z', 'M12 10v4', 'M12 17h.01'],
          cog: ['M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z', 'M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2'],
          doc: ['M6 3h8l4 4v14H6z', 'M14 3v4h4', 'M9 12h6M9 16h6'],
          calendar: ['M4 6h16v14H4z', 'M8 3v4M16 3v4', 'M4 10h16'],
          target: ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z', 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z', 'M12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2z'],
          chat: ['M4 5h16v10H9l-5 4z'],
        };
        return h('svg', {
          width: 13, height: 13, viewBox: '0 0 24 24', fill: 'none', stroke: color,
          strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round',
          style: { flexShrink: 0 },
        }, (paths[pick] || paths.chat).map((d, i) => h('path', { key: i, d })));
      };

      const renderStyledSummary = (md, tplId, keyBase) => {
        const th = themeOf(tplId);
        const doc = parseSummary(md);
        const kb = keyBase || 'md';

        const renderTable = (rows, key, compact) => {
          const [head, ...body] = rows;
          const cell = {
            padding: compact ? '5px 8px' : '7px 10px',
            fontSize: compact ? 12 : 12.5, lineHeight: '20px', color: T.ink2,
            borderBottom: `1px solid ${T.line}`, textAlign: 'left', verticalAlign: 'top', maxWidth: 260,
          };
          return h('div', {
            key,
            style: { margin: compact ? '6px 0 2px' : '6px 0 12px', border: `1px solid ${T.line}`,
                     borderRadius: 8, overflow: 'hidden', background: '#fff' },
          },
            h('table', { style: { width: '100%', borderCollapse: 'collapse' } },
              h('thead', null, h('tr', null, head.map((c, ci) => h('th', {
                key: ci, style: { ...cell, background: th.tint, color: T.ink, fontWeight: 600 },
              }, inline(c, `${key}-h${ci}`))))),
              h('tbody', null, body.map((row, ri) => h('tr', { key: ri },
                row.map((c, ci) => h('td', { key: ci, style: cell }, inline(c, `${key}-${ri}-${ci}`))))))));
        };

        // 一张卡：图标 + 标题 + 要点 + 结论条
        const renderCard = (g, key, color) => {
          const bullets = [];
          let concl = '';
          g.items.forEach((it) => {
            if (it.type === 'table') { bullets.push(it); return; }
            const m = /^\*\*(结论|小结)\*\*[：:]\s*(.*)$/.exec(it.text || '');
            if (m) { concl = m[2]; return; }
            bullets.push(it);
          });
          return h('div', {
            key,
            style: { background: '#fff', borderRadius: 12, padding: '12px 14px',
                     border: '1px solid #eceef2', boxShadow: '0 1px 2px rgba(29,33,41,.04)',
                     display: 'flex', flexDirection: 'column' },
          },
            h('div', { style: { display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 } },
              iconFor(g.title, color.fg),
              h('span', { style: { fontSize: 13, fontWeight: 600, color: T.ink } },
                inline(g.title, `${key}-t`))),
            h('div', { style: { flex: 1 } },
              bullets.map((it, ii) => (it.type === 'table'
                ? renderTable(it.rows, `${key}-tb${ii}`, true)
                : h('div', {
                    key: ii,
                    style: { display: 'flex', gap: 6, fontSize: 12.5, lineHeight: '21px',
                             color: T.ink2, marginBottom: 4 },
                  },
                    h('span', { style: { color: color.fg, flexShrink: 0, marginTop: 1 } }, '•'),
                    h('span', { style: { flex: 1 } }, inline(it.text, `${key}-b${ii}`)))))),
            concl ? h('div', {
              style: { marginTop: 8, padding: '7px 9px', borderRadius: 7, background: color.soft,
                       fontSize: 12, lineHeight: '18px', color: '#454b54' },
            }, inline(concl, `${key}-c`)) : null);
        };

        // 章节内一组块：卡片走三列网格，表格/段落整行
        const renderSectionBody = (sec, si, color) => {
          const nodes = [];
          const cards = [];
          const flushCards = (key) => {
            if (!cards.length) return;
            nodes.push(h('div', {
              key,
              style: { display: 'grid', gap: 10, marginBottom: 8,
                       gridTemplateColumns: cards.length === 1 ? '1fr'
                         : `repeat(auto-fit, minmax(${cards.length === 2 ? 300 : 240}px, 1fr))` },
            }, cards.map((g, gi) => renderCard(g, `${key}-c${gi}`, color))));
            cards.length = 0;
          };
          sec.blocks.forEach((b, bi) => {
            if (b.type === 'ul') { b.groups.forEach((g) => cards.push(g)); return; }
            flushCards(`g${si}-${bi}`);
            if (b.type === 'table') nodes.push(renderTable(b.rows, `t${si}-${bi}`, false));
            else if (b.type === 'p') nodes.push(h('div', {
              key: `p${si}-${bi}`,
              style: { fontSize: 12.5, lineHeight: '22px', color: T.ink2, margin: '2px 0 8px' },
            }, inline(b.text, `p${si}-${bi}`)));
            else if (b.type === 'todo') {
              nodes.push(h('div', { key: `w${si}-${bi}`, style: { margin: '2px 0 8px' } },
                b.items.map((it, ii) => h('div', {
                  key: ii,
                  style: { display: 'flex', gap: 8, fontSize: 12.5, lineHeight: '22px', color: T.ink2 },
                },
                  h('span', { style: { color: color.fg } }, it.done ? '☑' : '☐'),
                  h('span', { style: { flex: 1 } }, inline(it.text, `w${si}-${bi}-${ii}`))))));
            }
          });
          flushCards(`g${si}-end`);
          return nodes;
        };

        const palette = (themeOf(tplId).palette || DINGTALK4).map(([fg, soft]) => ({ bg: fg, fg, soft }));
        const renderSection = (sec, si) => {
          const color = palette[si % palette.length];
          return h('div', { key: `sec${si}`, style: { marginBottom: 18 } },
            h('div', { style: { display: 'flex', alignItems: 'center', marginBottom: 10 } },
              h('span', {
                style: { background: color.bg, color: '#fff', fontSize: 11.5, fontWeight: 700,
                         borderRadius: 5, padding: '3px 7px', marginRight: 8,
                         fontVariantNumeric: 'tabular-nums' },
              }, String(si + 1).padStart(2, '0')),
              h('span', { style: { fontSize: 14, fontWeight: 700, color: color.fg } },
                inline(sec.title, `st${si}`))),
            renderSectionBody(sec, si, color));
        };

        // AI 洞察：钉钉最后一块是宽卡 + 灯泡图标
        const insight = doc.insights && doc.insights.length ? h('div', {
          key: 'insight',
          style: { marginTop: 6, padding: '12px 14px', borderRadius: 12, background: '#fafafa',
                   border: '1px dashed #e3e5ea' },
        },
          h('div', { style: { display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 } },
            iconFor('洞察', '#8a8f99'),
            h('span', { style: { fontSize: 12.5, fontWeight: 600, color: '#6b7280' } }, 'AI 洞察')),
          doc.insights.map((t, i) => h('div', {
            key: i,
            style: { fontSize: 12.5, lineHeight: '21px', color: '#5b6270', marginBottom: 4 },
          }, inline(t, `in${i}`)))) : null;

        // 短章节（卡片 ≤2）两两并排，长章节通栏——对齐钉钉的 02/03 并排、04 通栏
        const shortSec = (sec) => {
          const cardBlock = (sec.blocks || []).find((b) => b.type === 'ul');
          return cardBlock ? cardBlock.groups.length <= 2 : false;
        };
        const packed = [];
        for (let i = 0; i < doc.sections.length; i += 1) {
          if (shortSec(doc.sections[i]) && i + 1 < doc.sections.length && shortSec(doc.sections[i + 1])) {
            packed.push(h('div', {
              key: `row${i}`,
              style: { display: 'grid', gap: 18, gridTemplateColumns: '1fr 1fr', alignItems: 'start' },
            }, renderSection(doc.sections[i], i), renderSection(doc.sections[i + 1], i + 1)));
            i += 1;
          } else {
            packed.push(renderSection(doc.sections[i], i));
          }
        }

        return h('div', {
          key: kb,
          style: { border: '1px solid #eceef2', borderRadius: 16, padding: '26px 28px 18px',
                   boxShadow: '0 2px 10px rgba(29,33,41,.04)', background: '#fff' },
        },
          // 封面
          doc.title ? h('div', { style: { padding: '2px 2px 14px', borderBottom: '1px solid #eef0f3',
                                          marginBottom: 16 } },
            h('div', { style: { fontSize: 22, fontWeight: 700, color: T.ink, lineHeight: '32px' } },
              inline(doc.title, `${kb}-t`)),
            doc.subtitle ? h('div', { style: { fontSize: 12.5, color: '#8a8f99', lineHeight: '20px',
                                               marginTop: 4 } }, inline(doc.subtitle, `${kb}-st`)) : null) : null,
          packed,
          insight,
          h('div', { style: { textAlign: 'center', fontSize: 11, color: '#b9bec7', margin: '14px 0 4px' } },
            'AI 生成可能有误，请核实细节'));
      };

      const renderSummary = () => h('div', { style: { padding: '4px 16px 16px' } },
        renderTpl(),

        renderMeta(),
        sel.artifacts && sel.artifacts.summary
          ? renderStyledSummary(String(sel.artifacts.summary), sel.template, 'md')
          : h('div', { style: { fontSize: 12.5, color: T.gray } }, '还没有纪要'));

      const chapters = (sel && sel.chapters) || [];
      const renderChapters = () => h('div', { style: { padding: '4px 16px 16px' } },
        chapters.length
          ? chapters.map((c, i) => h('div', {
              key: i,
              style: { padding: '10px 0', borderTop: i ? `1px solid ${T.line}` : 'none', cursor: 'pointer' },
              onClick: () => seekTo(Number(String(c.at).split(':')[0]) * 60 + Number(String(c.at).split(':')[1] || 0)),
            },
              h('div', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
                h('span', {
                  style: { fontSize: 11.5, color: '#4b5bdc', background: '#eef0fe', borderRadius: 999,
                           padding: '2px 8px', fontVariantNumeric: 'tabular-nums' },
                }, c.at),
                h('span', { style: { fontSize: 14.5, fontWeight: 600 } }, c.title)),
              h('div', { style: { fontSize: 13, color: T.gray, lineHeight: '22px', marginTop: 4,
                                  paddingLeft: 4 } }, c.summary)))
          : h('div', { style: { fontSize: 12.5, color: T.gray } }, '还没有章节（重跑一次纪要会生成）'));

      const renderAnalysis = () => h('div', { style: { padding: '4px 16px 16px' } },
        analysis
          ? h('div', null, [
              h('div', { key: 't1', style: { fontSize: 13, fontWeight: 600, margin: '6px 0' } }, '发言人'),
              ...((analysis.insights && analysis.insights.speakers) || []).map((sp, i) =>
                h('div', { key: `sp${i}`, style: { marginBottom: 10, fontSize: 12.5, lineHeight: '20px' } },
                  h('b', { style: { color: spkColor(speakerIds, sp.speaker) } }, spkName(sp.speaker)),
                  h('span', { style: { color: T.gray } }, ` · ${sp.role_guess || ''}`),
                  (sp.focus || []).length
                    ? h('div', { style: { color: T.ink2, marginTop: 2 } }, `关注：${(sp.focus || []).join('、')}`)
                    : null)),
              h('div', { key: 't2', style: { fontSize: 13, fontWeight: 600, margin: '12px 0 6px' } }, '思维导图'),
              ...(((analysis.mindmap && analysis.mindmap.children) || []).map((b, i) =>
                h('div', { key: `mb${i}`, style: { fontSize: 12.5, marginBottom: 6 } },
                  h('div', { style: { fontWeight: 500 } }, b.title),
                  (b.children || []).map((leaf, j) =>
                    h('div', { key: j, style: { color: T.gray, paddingLeft: 12 } }, `· ${leaf.title}`))))),
            ])
          : h('div', { style: { fontSize: 12.5, color: T.gray } }, '分析生成中…'));

      const renderTab = () => (tab === 'transcript' ? renderTranscript()
        : tab === 'chapters' ? renderChapters()
        : tab === 'analysis' ? renderAnalysis()
        : renderSummary());

      const jumpSpans = (text, keyBase) => {
        const out = [];
        const re = /\[(\d{1,2}):(\d{2})\]/g;
        let last = 0, m, k = 0;
        while ((m = re.exec(text)) !== null) {
          if (m.index > last) out.push(text.slice(last, m.index));
          const secs = Number(m[1]) * 60 + Number(m[2]);
          out.push(h('span', {
            key: `${keyBase}-j${k += 1}`,
            style: { color: '#2b6cff', cursor: 'pointer' },
            onClick: (e) => { e.stopPropagation(); seekTo(secs); },
          }, m[0]));
          last = m.index + m[0].length;
        }
        if (last < text.length) out.push(text.slice(last));
        return out;
      };

      const renderMd = (text, keyBase) => (text || '').split('\n').map((line, i) => {
        const t = line.replace(/\s+$/, '');
        if (!t.trim()) return h('div', { key: `${keyBase}-${i}`, style: { height: 6 } });
        if (t.startsWith('### ')) return h('div', { key: `${keyBase}-${i}`, style: { fontSize: 13, fontWeight: 600, margin: '8px 0 3px', color: T.ink } }, jumpSpans(t.slice(4), `${keyBase}-${i}`));
        if (t.startsWith('## ')) return h('div', { key: `${keyBase}-${i}`, style: { fontSize: 14.5, fontWeight: 600, margin: '12px 0 5px', color: T.ink } }, jumpSpans(t.slice(3), `${keyBase}-${i}`));
        if (t.startsWith('# ')) return h('div', { key: `${keyBase}-${i}`, style: { fontSize: 16, fontWeight: 700, margin: '4px 0 8px', color: T.ink } }, jumpSpans(t.slice(2), `${keyBase}-${i}`));
        if (t.startsWith('> ')) return h('div', { key: `${keyBase}-${i}`, style: { fontSize: 12.5, color: T.gray, borderLeft: `2px solid ${T.line}`, paddingLeft: 8, margin: '3px 0' } }, jumpSpans(t.slice(2), `${keyBase}-${i}`));
        if (/^[-*] /.test(t)) return h('div', { key: `${keyBase}-${i}`, style: { fontSize: 13.5, lineHeight: '23px', display: 'flex', gap: 6, color: T.ink2 } },
          h('span', { style: { color: T.accent } }, '•'), h('span', { style: { flex: 1 } }, jumpSpans(t.slice(2), `${keyBase}-${i}`)));
        return h('div', { key: `${keyBase}-${i}`, style: { fontSize: 13.5, lineHeight: '23px', color: T.ink2 } }, jumpSpans(t, `${keyBase}-${i}`));
      });

      const renderDetail = () => h('div', { style: { display: 'flex', flexDirection: 'column', minHeight: 0, flex: 1 } },
        h('div', {
          style: { display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px',
                   borderBottom: `1px solid ${T.line}`, flexShrink: 0 },
        },
          h('button', { style: { ...ghost, border: 'none', padding: '2px 6px' }, onClick: () => setSel(null) }, '←'),
          h('span', {
            style: { flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis',
                     whiteSpace: 'nowrap', fontSize: 14, fontWeight: 600, cursor: 'text' },
            title: `${sel.title || sel.id}（双击可改标题）`,
            onDoubleClick: async () => {
              const next = window.prompt('改标题（回车保存，取消放弃）', sel.title || '');
              if (next === null) return;
              const v = next.trim();
              if (!v || v === sel.title) return;
              try {
                const r = await apiFetch(`/v1/minutes/${sel.id}`, {
                  method: 'PATCH', headers: { 'content-type': 'application/json' },
                  body: JSON.stringify({ title: v, title_auto: 0 }),
                });
                if (!r.ok) throw new Error(`HTTP ${r.status}`);
                const fresh = await r.json();
                setSel(fresh);
                loadList(false);
                setProgress('标题已更新');
              } catch (e) { setProgress(`改标题失败：${e.message}`); }
            },
          }, sel.title || sel.id),
          h('button', {
            style: { ...ghost, padding: '4px 8px', fontSize: 11.5 },
            title: '在新标签页打开图文纪要（可分享 / 打印）',
            onClick: () => window.open(
              `${apiBase()}/v1/minutes/${sel.id}/view?o=${encodeURIComponent(ownerId)}`, '_blank'),
          }, '浏览器打开'),
          h('button', {
            style: { ...ghost, padding: '4px 8px', fontSize: 11.5 },
            title: '下载 Markdown',
            onClick: () => window.open(`${apiBase()}/v1/minutes/${sel.id}/export?format=md&o=${encodeURIComponent(ownerId)}`, '_blank'),
          }, 'Markdown'),
          h('button', {
            style: { ...ghost, padding: '4px 8px', fontSize: 11.5 },
            onClick: async () => {
              try {
                const r = await apiFetch(`/v1/minutes/${sel.id}/share`, {
                  method: 'POST', headers: { 'content-type': 'application/json' },
                  body: JSON.stringify({ ttl_hours: 72 }),
                });
                if (!r.ok) throw new Error(`HTTP ${r.status}`);
                const d = await r.json();
                const url = `${apiBase()}${d.url}`;
                let copied = false;
                try {
                  if (navigator.clipboard) { await navigator.clipboard.writeText(url); copied = true; }
                } catch (e) { /* ignore */ }
                setProgress(copied
                  ? `分享链接已复制（72 小时有效）：${url}`
                  : `分享链接（72 小时有效）：${url}`);
                window.open(url, '_blank');
              } catch (e) { setProgress(`分享失败：${e.message}`); }
            },
          }, '分享')),
        renderPlayer(),
        h('div', {
          style: { display: 'flex', padding: '0 16px', borderBottom: `1px solid ${T.line}`, flexShrink: 0 },
        },
          tabBtn('transcript', '转写'), tabBtn('summary', 'AI纪要'),
          tabBtn('chapters', '章节'), tabBtn('analysis', '分析')),
        h('div', { style: { overflow: 'auto', minHeight: 0, flex: 1 } },
          h('div', { style: { maxWidth: 880, paddingBottom: 24 } }, renderTab())));

      // ===== 组装 =====
      const listArea = h('div', { style: { overflow: 'auto', minHeight: 0, flex: 1 } },
        h('div', { style: { padding: '10px 14px', borderBottom: `1px solid ${T.line}` } },
          h('input', {
            value: q,
            placeholder: '搜索标题或内容，回车',
            onChange: (e) => { setQ(e.target.value); if (!e.target.value.trim()) setHits([]); },
            onKeyDown: (e) => { if (e.key === 'Enter') runSearch(); },
            style: {
              width: '100%', boxSizing: 'border-box', padding: '7px 12px', borderRadius: 999,
              border: `1px solid ${T.line}`, background: T.soft, color: T.ink,
              fontSize: 12.5, outline: 'none', fontFamily: FONT,
            },
          })),
        listBody,
        !hits.length && cursor
          ? h('div', { style: { padding: '10px 18px 14px' } },
              h('button', { style: { ...ghost, width: '100%' }, onClick: () => loadList(true) }, '加载更多'))
          : null);

      const footer = h('div', {
        key: 'ft',
        style: { padding: '8px 16px', borderTop: `1px solid ${T.line}`, fontSize: 11.5,
                 color: T.gray, flexShrink: 0, display: 'flex', gap: 8, alignItems: 'center' },
      },
        h('button', { style: { ...ghost, padding: '3px 8px', fontSize: 11.5 }, onClick: () => loadList(false) }, '刷新'),
        h('button', {
          style: { ...ghost, padding: '3px 8px', fontSize: 11.5, color: T.gray },
          title: `当前数据空间：${ownerId}`,
          onClick: () => {
            const next = window.prompt(
              '当前数据空间（换一个就是全新的空空间，用于验证别人装完能看到什么）\n留空 = 生成一个新的随机空间',
              ownerId,
            );
            if (next === null) return;
            try {
              window.localStorage.setItem('aim_owner', (next || '').trim() || ('u_' + Math.random().toString(36).slice(2, 10)));
            } catch (e) { /* ignore */ }
            window.location.reload();
          },
        }, `空间：${ownerName || ownerId.slice(0, 14)}`),
        h('span', { style: { flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } },
          err || progress || ''));

      const sideList = h('div', {
        key: 'side',
        style: { width: listW, flexShrink: 0, borderRight: `1px solid ${T.line}`,
                 display: 'flex', flexDirection: 'column', minHeight: 0, background: '#fbfbfc' },
      },
        h('div', { style: { padding: '12px 14px', borderBottom: `1px solid ${T.line}` } },
          h('input', {
            value: q,
            placeholder: '搜索标题或内容，回车',
            onChange: (e) => { setQ(e.target.value); if (!e.target.value.trim()) setHits([]); },
            onKeyDown: (e) => { if (e.key === 'Enter') runSearch(); },
            style: { width: '100%', boxSizing: 'border-box', padding: '8px 14px', borderRadius: 999,
                     border: `1px solid ${T.line}`, background: T.bg, color: T.ink,
                     fontSize: 12.5, outline: 'none', fontFamily: FONT },
          })),
        h('div', { style: { overflow: 'auto', minHeight: 0, flex: 1 } }, listBody,
          !hits.length && cursor
            ? h('div', { style: { padding: '10px 18px 14px' } },
                h('button', { style: { ...ghost, width: '100%' }, onClick: () => loadList(true) }, '加载更多'))
            : null),
        footer);

      const inRecordView = recording && recState.expanded;
      const mainArea = inRecordView
        ? recArea
        : (sel
            ? renderDetail()
            : h('div', { key: 'idle', style: { flex: 1, display: 'flex', flexDirection: 'column',
                                              alignItems: 'center', justifyContent: 'center', gap: 10 } },
                h('button', { style: heroMic, onClick: startRecording, title: '开始录音' }, '🎙'),
                h('div', { style: { fontSize: 15, fontWeight: 500, color: T.ink } }, '点击开始录音'),
                h('div', { style: { fontSize: 12.5, color: T.gray } }, '结束后自动生成逐字稿与总结'),
                h('div', { style: { display: 'flex', gap: 8, marginTop: 8 } },
                  h('button', { style: ghost, onClick: () => fileRef.current && fileRef.current.click() }, '上传音视频'),
                  h('label', { style: { ...ghost, display: 'inline-flex', alignItems: 'center', gap: 4 } },
                    h('input', {
                      type: 'checkbox', checked: liveMode,
                      onChange: (e) => setLiveMode(e.target.checked),
                    }), '实时转写'))));

      const fileInput = h('input', {
        key: 'file',
        ref: fileRef,
        type: 'file',
        accept: 'audio/*,video/*,.m4a,.mp3,.wav,.mp4,.mov,.aac,.flac,.ogg,.webm',
        style: { display: 'none' },
        onChange: (e) => {
          const f = e.target.files && e.target.files[0];
          if (f) upload(f);
          e.target.value = '';
        },
      });

      return h('div', {
        style: { height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0,
                 background: T.bg, color: T.ink, fontFamily: FONT },
      },
        fileInput,
        header,
        h('div', { style: { flex: 1, display: 'flex', minHeight: 0 } }, sideList,
          h('div', {
            key: 'split',
            onMouseDown: startDrag,
            title: '拖动调整列表宽度',
            style: { width: 6, cursor: 'col-resize', flexShrink: 0, marginLeft: -3,
                     background: 'transparent', position: 'relative' },
          }),
          h('div', { style: { flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, minHeight: 0 } },
            mainArea)));
    }


    // ===== 录音最小化浮条 =====
    // 录音状态在模块单例里，所以用户切到别的面板时，这一条会一直显示，
    // 直到用户自己点「完成」或「取消」——不会被页面卸载打断。
    function RecorderBar() {
      const [st, setSt] = React.useState(Recorder.snapshot());
      React.useEffect(() => Recorder.on(setSt), []);
      if (!st.active || st.expanded) return null;
      const secs = st.secs || 0;
      return h('div', {
        style: { position: 'fixed', right: 24, bottom: 96, zIndex: 2147483000, width: 320,
                 background: T.bg, border: `1px solid ${T.line}`, borderRadius: 14,
                 boxShadow: '0 12px 32px rgba(29,33,41,.18)', padding: '10px 14px',
                 display: 'flex', alignItems: 'center', gap: 10, fontFamily: FONT, color: T.ink },
      },
        h('span', { style: { display: 'inline-flex', gap: 2, alignItems: 'flex-end', height: 16 } },
          [0, 1, 2, 3, 4, 5].map((i) => h('span', {
            key: i,
            style: { width: 3, borderRadius: 2, background: '#f45b69',
                     height: st.paused ? 4 : 5 + Math.abs(Math.sin(secs * 1.6 + i)) * 11 },
          }))),
        h('span', { style: { fontVariantNumeric: 'tabular-nums', fontSize: 13, color: T.gray, minWidth: 46 } },
          `${String(Math.floor(secs / 60)).padStart(2, '0')}:${String(secs % 60).padStart(2, '0')}`),
        h('span', { style: { flex: 1 } }),
        h('button', {
          style: { ...ghost, border: 'none', padding: '2px 6px', fontSize: 15, color: T.ink2 },
          onClick: () => Recorder.togglePause(), title: st.paused ? '继续' : '暂停',
        }, st.paused ? '▶' : '⏸'),
        h('button', {
          style: { ...ghost, border: 'none', padding: '2px 6px', fontSize: 13, fontWeight: 600 },
          onClick: () => Recorder.stop(), title: '结束并生成听记',
        }, '完成'),
        h('button', {
          style: { ...ghost, border: 'none', padding: '2px 6px', fontSize: 13, color: T.gray },
          onClick: () => Recorder.cancel(), title: '取消本次录音',
        }, '取消'),
        st.pageVisible ? h('button', {
          style: { ...ghost, border: 'none', padding: '2px 4px', fontSize: 15, color: T.gray },
          onClick: () => Recorder.setExpanded(true), title: '展开录音界面',
        }, '⤢') : null);
    }

    // 侧栏一级菜单图标（宿主给 size / active，颜色用 currentColor 跟随主题）
    function MinutesIcon(props) {
      const size = (props && props.size) || 18;
      return h('svg', {
        width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
        stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round',
        strokeLinejoin: 'round', 'aria-hidden': 'true',
      },
        h('rect', { x: 9, y: 2.5, width: 6, height: 12, rx: 3 }),
        h('path', { d: 'M5 11a7 7 0 0 0 14 0' }),
        h('path', { d: 'M12 18v4' }),
        h('path', { d: 'M8.5 22h7' }));
    }

    return {
      inject: ['slots'],
      apply(ctx) {
        // 「AI听记」作为左侧一级菜单：sidebar.panellist 提供图标，main 提供同一 id 的页面
        ctx.slots.inject('sidebar.panellist', () => ctx.slots.register({
          name: 'sidebar.panellist', id: 'ai-minutes', order: 8, label: 'AI听记',
        }, MinutesIcon));
        ctx.slots.inject('main', () => ctx.slots.register({
          name: 'main', key: 'ai-minutes',
        }, Minutes));
        // 录音中切到别处时，用一个浮条保持可见、可停
        ctx.slots.inject('shell.overlay', () => ctx.slots.register({
          name: 'shell.overlay', id: 'ai-minutes-recorder', order: 45,
        }, RecorderBar));
      },
    };
  },
});
