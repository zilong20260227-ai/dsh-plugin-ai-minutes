#!/bin/bash
# 双击运行：把插件复制到一个固定位置，并打印要粘贴到 DSH「添加插件」里的路径
set -e
cd "$(dirname "$0")"
DEST="$HOME/.dsh-plugins/ai-minutes"
mkdir -p "$HOME/.dsh-plugins"
rm -rf "$DEST"
cp -R . "$DEST"
rm -f "$DEST/安装.command" "$DEST/安装说明.txt"
chmod 600 "$DEST/key/id_ed25519" 2>/dev/null || true
echo ""
echo "=============================================="
echo " 装好了。把下面这一行完整复制，"
echo " 粘贴到 DSH → 插件 → + 添加插件 的输入框里："
echo ""
echo "   $DEST"
echo ""
echo "=============================================="
echo ""
echo "粘贴后点安装 → 提示需要重启时就重启 DSH。"
echo "（按回车关闭这个窗口）"
read -r _
